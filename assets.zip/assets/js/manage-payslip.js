(function($){
	$(document).ready(function(){
		$('.datepicker').datepicker({
			orientation: 'bottom'
		});
	});
})(jQuery)